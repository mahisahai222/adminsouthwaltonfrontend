### Bug reports

See the [contributing guidelines](CONTRIBUTING.md) for sharing bug reports.

### How-to

For general troubleshooting or help getting started:

- Search or start a new discussion on [GitHub Discussions](https://github.com/coreui/coreui-free-react-admin-template/discussions).
